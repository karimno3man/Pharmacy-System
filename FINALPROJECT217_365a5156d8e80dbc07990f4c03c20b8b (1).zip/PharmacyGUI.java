import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PharmacyGUI {
    private Pharmacy pharmacy;
    private JFrame frame;

    public PharmacyGUI() {
        // Ask for the pharmacy capacity at the start
        String capacityStr = JOptionPane.showInputDialog("Enter the capacity of the pharmacy:");
        int capacity = Integer.parseInt(capacityStr);
        pharmacy = new Pharmacy(capacity);

        // Create the main frame
        frame = new JFrame("Pharmacy Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLayout(new BorderLayout());

        // Create and add the main panel
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 1));

        // Add buttons
        JButton addButton = new JButton("Add Drug");
        JButton removeButton = new JButton("Remove Drug");
        JButton orderButton = new JButton("Place Order");
        JButton salesButton = new JButton("Total Sales");
        JButton exitButton = new JButton("Exit");


        panel.add(addButton);
        panel.add(removeButton);
        panel.add(orderButton);
        panel.add(salesButton);
        panel.add(exitButton);

        // Add action listeners
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addDrug();
            }
        });

        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeDrug();
            }
        });

        orderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                placeOrder();
            }
        });

        salesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayTotalSales();
            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });

        frame.add(panel, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    private void addDrug() {
        JTextField nameField = new JTextField(10);
        JTextField idField = new JTextField(10);
        JTextField priceField = new JTextField(10);
        JTextField categoryField = new JTextField(10);
        JTextField quantityField = new JTextField(10);
        JCheckBox prescriptionCheckBox = new JCheckBox("Prescription Required");

        JPanel addPanel = new JPanel();
        addPanel.add(new JLabel("Name:"));
        addPanel.add(nameField);
        addPanel.add(new JLabel("ID:"));
        addPanel.add(idField);
        addPanel.add(new JLabel("Price:"));
        addPanel.add(priceField);
        addPanel.add(new JLabel("Category:"));
        addPanel.add(categoryField);
        addPanel.add(new JLabel("Available Quantity:"));
        addPanel.add(quantityField);
        addPanel.add(prescriptionCheckBox);

        int result = JOptionPane.showConfirmDialog(frame, addPanel, "Add Drug", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String name = nameField.getText();
            int id = Integer.parseInt(idField.getText());
            double price = Double.parseDouble(priceField.getText());
            String category = categoryField.getText();
            int quantity = Integer.parseInt(quantityField.getText());
            boolean prescriptionRequired = prescriptionCheckBox.isSelected();

            pharmacy.addDrug(name, id, price, category, quantity, prescriptionRequired);
        }
    }

    private void removeDrug() {
        String idStr = JOptionPane.showInputDialog(frame, "Enter Drug ID to Remove:");
        int id = Integer.parseInt(idStr);
        pharmacy.removeDrug(id);
    }

    private void placeOrder() {
        String idStr = JOptionPane.showInputDialog(frame, "Enter Drug ID to Order:");
        int id = Integer.parseInt(idStr);
        pharmacy.placeOrder(id);
    }

    private void displayTotalSales() {
        double totalSales = pharmacy.getTotalSales();
        JOptionPane.showMessageDialog(frame, "Total Sales: " + totalSales);
    }

    public static void main(String[] args) {
        new PharmacyGUI();
    }
}
